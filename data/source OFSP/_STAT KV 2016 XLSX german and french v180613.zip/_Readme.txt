README FR

Comment acc�der aux tableaux Excel de la statistique de l'assurance-maladie obligatoire ?

1) t�l�charger le fichier zip sur votre ordinateur

2) Extrayez les fichiers du dossier zip sur votre ordinateur

3) La table des mati�res indique la date de mise en ligne des tableaux et les �ventuelles corrections.
   Le premier tableau (00) de chaque r�pertoire T01 � T11 contient �galement la table des mati�res des tableaux du chapitre.

4) La liste des tableaux �num�re tous les tableaux par chapitre, en indiquant le cas �ch�ant les nouveaux tableaux

5) Le r�pertoire "T00 Annexe" met en �vidence les nouveaux tableaux et graphiques ainsi que les modifications, 
   de m�me que les �quivalences dans les pr�c�dentes publications � partir de 1996.

6) Si un message similaire � 
   "Nous n'avons pas pu ouvrir ce fichier. Veuillez lui attribuer un nom plus court ou copiez-le dans un autre dossier pour lequel le chemin d'acc�s est plus court" 
   appara�t lors de l'ouverture d'un tableau Excel, c'est que la limite des 260 caract�res dans Windows pour le chemin d'acc�s a �t� d�pass�e. 
   Soit d�placez le r�pertoire pour avoir un chemin d'acc�s plus court soit renommez les r�pertoires T01 � T11 pour les raccourcir.


README DE

Wie kann man auf Excel-Tabellen der Krankenversicherungsstatistiken zugreifen?

1) Laden Sie die ZIP-Datei auf Ihren Computer herunter

2) Extrahieren Sie die Dateien aus dem ZIP-Ordner auf Ihren Computer

3) Das Inhaltsverzeichnis enth�lt das Datum der Ver�ffentlichung der Tabellen und etwaige Korrekturen.
   Die erste Tabelle (00) jedes Verzeichnisses T01 bis T11 enth�lt auch das Inhaltsverzeichnis der Tabellen in diesem Kapitel.

4) Die Liste der Tabellen listet alle Tabellen nach Kapiteln auf und zeigt gegebenenfalls die neuen Tabellen an

5) Das Verzeichnis "T00 Beilage" zeigt neue Tabellen und Grafiken sowie �nderungen an, 
   sowie �quivalenzen in fr�heren Ver�ffentlichungen ab 1996

6) Wenn beim �ffnen einer Excel-Tabelle eine �hnliche Meldung wie 
   "Wir konnten diese Datei nicht �ffnen, geben Sie ihr einen k�rzeren Namen oder kopieren Sie sie in einen anderen Ordner, f�r den der Pfad k�rzer ist" 
   angezeigt wird, wurde der Grenzwert von 260 Zeichen in Windows f�r den Pfad �berschritten.
   Entweder verschieben Sie das Verzeichnis, um einen k�rzeren Pfad zu haben, oder benennen Sie die Verzeichnisse T01 bis T11 um, um sie zu verk�rzen